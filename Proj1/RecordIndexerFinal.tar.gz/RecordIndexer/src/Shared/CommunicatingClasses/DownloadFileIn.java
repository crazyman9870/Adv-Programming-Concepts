package Shared.CommunicatingClasses;

public class DownloadFileIn {

	private String url;
	
	public DownloadFileIn(String url) {
		this.url = url;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
}
